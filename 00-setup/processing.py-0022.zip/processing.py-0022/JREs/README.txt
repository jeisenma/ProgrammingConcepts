

If you put Oracle's JRE here as

jre7.mac 
jre7.win

it will be used instead of your system's version.
