

Extract any official Processing 2.0 plug-in into the "processing" folder.

