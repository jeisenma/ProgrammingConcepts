/*
 * Copyright 2010 Jonathan Feinberg
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
/*[[[cog
    import processing_parser as p
    import cog
    ]]]
  [[[end]]] */
package jycessing;

import org.python.util.InteractiveConsole;
import org.python.core.*;
import processing.core.*;
import processing.event.*;
import processing.opengl.*;
import java.io.*;

@SuppressWarnings("serial")
public class DriverImpl extends PAppletJythonDriver {

	public DriverImpl(final InteractiveConsole interp,
	        final String sketchPath, final String programText) {
		super(interp, sketchPath, programText);
	}
	
	
	@Override
	protected void populateBuiltins() {
	   /*[[[cog
	   for b in p.simple_method_bindings:
	       b.emit()
	   ]]]*/
	   builtins.__setitem__("quad",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"quad\" with " + args.length + " parameters."); 
	   			case 8: {
	   				quad((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble(), (float)args[5].asDouble(), (float)args[6].asDouble(), (float)args[7].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("pause",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"pause\" with " + args.length + " parameters."); 
	   			case 0: {
	   				pause();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("loadXML",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"loadXML\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return Py.java2py(loadXML(args[0].asString()));
	   			}
	   			case 2: {
	   				return Py.java2py(loadXML(args[0].asString(), args[1].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("arc",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"arc\" with " + args.length + " parameters."); 
	   			case 6: {
	   				arc((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble(), (float)args[5].asDouble());
	   				return Py.None;
	   			}
	   			case 7: {
	   				arc((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble(), (float)args[5].asDouble(), args[6].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("vertex",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"vertex\" with " + args.length + " parameters."); 
	   			case 1: {
	   				vertex((float[])args[0].__tojava__(float[].class));
	   				return Py.None;
	   			}
	   			case 2: {
	   				vertex((float)args[0].asDouble(), (float)args[1].asDouble());
	   				return Py.None;
	   			}
	   			case 3: {
	   				vertex((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble());
	   				return Py.None;
	   			}
	   			case 4: {
	   				vertex((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble());
	   				return Py.None;
	   			}
	   			case 5: {
	   				vertex((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("blendMode",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"blendMode\" with " + args.length + " parameters."); 
	   			case 1: {
	   				blendMode(args[0].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("screenX",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"screenX\" with " + args.length + " parameters."); 
	   			case 2: {
	   				return new PyFloat(screenX((float)args[0].asDouble(), (float)args[1].asDouble()));
	   			}
	   			case 3: {
	   				return new PyFloat(screenX((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("translate",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"translate\" with " + args.length + " parameters."); 
	   			case 2: {
	   				translate((float)args[0].asDouble(), (float)args[1].asDouble());
	   				return Py.None;
	   			}
	   			case 3: {
	   				translate((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("exec",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"exec\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return Py.java2py(exec((String[])args[0].__tojava__(String[].class)));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("resume",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"resume\" with " + args.length + " parameters."); 
	   			case 0: {
	   				resume();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("clip",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"clip\" with " + args.length + " parameters."); 
	   			case 4: {
	   				clip((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("requestImage",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"requestImage\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return Py.java2py(requestImage(args[0].asString()));
	   			}
	   			case 2: {
	   				return Py.java2py(requestImage(args[0].asString(), args[1].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("textureWrap",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"textureWrap\" with " + args.length + " parameters."); 
	   			case 1: {
	   				textureWrap(args[0].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("lights",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"lights\" with " + args.length + " parameters."); 
	   			case 0: {
	   				lights();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("loadImage",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"loadImage\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return Py.java2py(loadImage(args[0].asString()));
	   			}
	   			case 2: {
	   				return Py.java2py(loadImage(args[0].asString(), args[1].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("loadShader",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"loadShader\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return Py.java2py(loadShader(args[0].asString()));
	   			}
	   			case 2: {
	   				return Py.java2py(loadShader(args[0].asString(), args[1].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("lerp",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"lerp\" with " + args.length + " parameters."); 
	   			case 3: {
	   				return new PyFloat(lerp((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("canDraw",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"canDraw\" with " + args.length + " parameters."); 
	   			case 0: {
	   				return new PyBoolean(canDraw());
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("rect",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"rect\" with " + args.length + " parameters."); 
	   			case 4: {
	   				rect((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble());
	   				return Py.None;
	   			}
	   			case 5: {
	   				rect((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble());
	   				return Py.None;
	   			}
	   			case 8: {
	   				rect((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble(), (float)args[5].asDouble(), (float)args[6].asDouble(), (float)args[7].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("curve",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"curve\" with " + args.length + " parameters."); 
	   			case 8: {
	   				curve((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble(), (float)args[5].asDouble(), (float)args[6].asDouble(), (float)args[7].asDouble());
	   				return Py.None;
	   			}
	   			case 12: {
	   				curve((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble(), (float)args[5].asDouble(), (float)args[6].asDouble(), (float)args[7].asDouble(), (float)args[8].asDouble(), (float)args[9].asDouble(), (float)args[10].asDouble(), (float)args[11].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("get",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"get\" with " + args.length + " parameters."); 
	   			case 0: {
	   				return Py.java2py(get());
	   			}
	   			case 2: {
	   				return new PyInteger(get(args[0].asInt(), args[1].asInt()));
	   			}
	   			case 4: {
	   				return Py.java2py(get(args[0].asInt(), args[1].asInt(), args[2].asInt(), args[3].asInt()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("createReader",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"createReader\" with " + args.length + " parameters."); 
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if ((t0 == PyString.TYPE|| t0 == PyUnicode.TYPE)) {
	   					return Py.java2py(createReader(args[0].asString()));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == InputStream.class) {
	   					return Py.java2py(createReader((java.io.InputStream)args[0].__tojava__(java.io.InputStream.class)));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == File.class) {
	   					return Py.java2py(createReader((java.io.File)args[0].__tojava__(java.io.File.class)));
	   				} else { throw new UnexpectedInvocationError("createReader", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("loadJSONArray",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"loadJSONArray\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return Py.java2py(loadJSONArray(args[0].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("style",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"style\" with " + args.length + " parameters."); 
	   			case 1: {
	   				style((processing.core.PStyle)args[0].__tojava__(processing.core.PStyle.class));
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("ellipseMode",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"ellipseMode\" with " + args.length + " parameters."); 
	   			case 1: {
	   				ellipseMode(args[0].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("millis",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"millis\" with " + args.length + " parameters."); 
	   			case 0: {
	   				return new PyInteger(millis());
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("strokeWeight",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"strokeWeight\" with " + args.length + " parameters."); 
	   			case 1: {
	   				strokeWeight((float)args[0].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("point",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"point\" with " + args.length + " parameters."); 
	   			case 2: {
	   				point((float)args[0].asDouble(), (float)args[1].asDouble());
	   				return Py.None;
	   			}
	   			case 3: {
	   				point((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("acos",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"acos\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyFloat(acos((float)args[0].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("noFill",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"noFill\" with " + args.length + " parameters."); 
	   			case 0: {
	   				noFill();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("sort",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"sort\" with " + args.length + " parameters."); 
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if (t0.getProxyType() != null && t0.getProxyType() == int[].class) {
	   					return Py.java2py(sort((int[])args[0].__tojava__(int[].class)));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == float[].class) {
	   					return Py.java2py(sort((float[])args[0].__tojava__(float[].class)));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == byte[].class) {
	   					return Py.java2py(sort((byte[])args[0].__tojava__(byte[].class)));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == String[].class) {
	   					return Py.java2py(sort((String[])args[0].__tojava__(String[].class)));
	   				} else { throw new UnexpectedInvocationError("sort", args, kws); }
	   			}
	   			case 2: {
	   				final PyType t0 = args[0].getType();
	   				final PyType t1 = args[1].getType();
	   				if (t0.getProxyType() != null && t0.getProxyType() == int[].class && t1 == PyInteger.TYPE) {
	   					return Py.java2py(sort((int[])args[0].__tojava__(int[].class), args[1].asInt()));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == float[].class && t1 == PyInteger.TYPE) {
	   					return Py.java2py(sort((float[])args[0].__tojava__(float[].class), args[1].asInt()));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == byte[].class && t1 == PyInteger.TYPE) {
	   					return Py.java2py(sort((byte[])args[0].__tojava__(byte[].class), args[1].asInt()));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == String[].class && t1 == PyInteger.TYPE) {
	   					return Py.java2py(sort((String[])args[0].__tojava__(String[].class), args[1].asInt()));
	   				} else { throw new UnexpectedInvocationError("sort", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("smooth",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"smooth\" with " + args.length + " parameters."); 
	   			case 0: {
	   				smooth();
	   				return Py.None;
	   			}
	   			case 1: {
	   				smooth(args[0].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("floor",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"floor\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyInteger(floor((float)args[0].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("sqrt",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"sqrt\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyFloat(sqrt((float)args[0].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("specular",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"specular\" with " + args.length + " parameters."); 
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if (t0 == PyInteger.TYPE) {
	   					specular(args[0].asInt());
	   				return Py.None;
	   				} else if ((t0 == PyFloat.TYPE || t0 == PyInteger.TYPE || t0 == PyLong.TYPE)) {
	   					specular((float)args[0].asDouble());
	   				return Py.None;
	   				} else { throw new UnexpectedInvocationError("specular", args, kws); }
	   			}
	   			case 3: {
	   				specular((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("save",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"save\" with " + args.length + " parameters."); 
	   			case 1: {
	   				save(args[0].asString());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("unhex",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"unhex\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyInteger(unhex(args[0].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("loadTable",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"loadTable\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return Py.java2py(loadTable(args[0].asString()));
	   			}
	   			case 2: {
	   				return Py.java2py(loadTable(args[0].asString(), args[1].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("ambientLight",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"ambientLight\" with " + args.length + " parameters."); 
	   			case 3: {
	   				ambientLight((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble());
	   				return Py.None;
	   			}
	   			case 6: {
	   				ambientLight((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble(), (float)args[5].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("colorMode",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"colorMode\" with " + args.length + " parameters."); 
	   			case 1: {
	   				colorMode(args[0].asInt());
	   				return Py.None;
	   			}
	   			case 2: {
	   				colorMode(args[0].asInt(), (float)args[1].asDouble());
	   				return Py.None;
	   			}
	   			case 4: {
	   				colorMode(args[0].asInt(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble());
	   				return Py.None;
	   			}
	   			case 5: {
	   				colorMode(args[0].asInt(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("rotateZ",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"rotateZ\" with " + args.length + " parameters."); 
	   			case 1: {
	   				rotateZ((float)args[0].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("line",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"line\" with " + args.length + " parameters."); 
	   			case 4: {
	   				line((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble());
	   				return Py.None;
	   			}
	   			case 6: {
	   				line((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble(), (float)args[5].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("textAscent",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"textAscent\" with " + args.length + " parameters."); 
	   			case 0: {
	   				return new PyFloat(textAscent());
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("hint",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"hint\" with " + args.length + " parameters."); 
	   			case 1: {
	   				hint(args[0].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("unbinary",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"unbinary\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyInteger(unbinary(args[0].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("rectMode",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"rectMode\" with " + args.length + " parameters."); 
	   			case 1: {
	   				rectMode(args[0].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("noiseSeed",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"noiseSeed\" with " + args.length + " parameters."); 
	   			case 1: {
	   				noiseSeed(args[0].asLong());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("createGraphics",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"createGraphics\" with " + args.length + " parameters."); 
	   			case 2: {
	   				return Py.java2py(createGraphics(args[0].asInt(), args[1].asInt()));
	   			}
	   			case 3: {
	   				return Py.java2py(createGraphics(args[0].asInt(), args[1].asInt(), args[2].asString()));
	   			}
	   			case 4: {
	   				return Py.java2py(createGraphics(args[0].asInt(), args[1].asInt(), args[2].asString(), args[3].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("minute",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"minute\" with " + args.length + " parameters."); 
	   			case 0: {
	   				return new PyInteger(minute());
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("screenZ",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"screenZ\" with " + args.length + " parameters."); 
	   			case 3: {
	   				return new PyFloat(screenZ((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("noSmooth",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"noSmooth\" with " + args.length + " parameters."); 
	   			case 0: {
	   				noSmooth();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("bezierPoint",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"bezierPoint\" with " + args.length + " parameters."); 
	   			case 5: {
	   				return new PyFloat(bezierPoint((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("curvePoint",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"curvePoint\" with " + args.length + " parameters."); 
	   			case 5: {
	   				return new PyFloat(curvePoint((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("tan",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"tan\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyFloat(tan((float)args[0].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("radians",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"radians\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyFloat(radians((float)args[0].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("matchAll",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"matchAll\" with " + args.length + " parameters."); 
	   			case 2: {
	   				return Py.java2py(matchAll(args[0].asString(), args[1].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("textDescent",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"textDescent\" with " + args.length + " parameters."); 
	   			case 0: {
	   				return new PyFloat(textDescent());
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("applyMatrix",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"applyMatrix\" with " + args.length + " parameters."); 
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if (t0.getProxyType() != null && t0.getProxyType() == PMatrix3D.class) {
	   					applyMatrix((processing.core.PMatrix3D)args[0].__tojava__(processing.core.PMatrix3D.class));
	   				return Py.None;
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == PMatrix2D.class) {
	   					applyMatrix((processing.core.PMatrix2D)args[0].__tojava__(processing.core.PMatrix2D.class));
	   				return Py.None;
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == PMatrix.class) {
	   					applyMatrix((processing.core.PMatrix)args[0].__tojava__(processing.core.PMatrix.class));
	   				return Py.None;
	   				} else { throw new UnexpectedInvocationError("applyMatrix", args, kws); }
	   			}
	   			case 6: {
	   				applyMatrix((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble(), (float)args[5].asDouble());
	   				return Py.None;
	   			}
	   			case 16: {
	   				applyMatrix((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble(), (float)args[5].asDouble(), (float)args[6].asDouble(), (float)args[7].asDouble(), (float)args[8].asDouble(), (float)args[9].asDouble(), (float)args[10].asDouble(), (float)args[11].asDouble(), (float)args[12].asDouble(), (float)args[13].asDouble(), (float)args[14].asDouble(), (float)args[15].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("saveJSONObject",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"saveJSONObject\" with " + args.length + " parameters."); 
	   			case 2: {
	   				return new PyBoolean(saveJSONObject((processing.data.JSONObject)args[0].__tojava__(processing.data.JSONObject.class), args[1].asString()));
	   			}
	   			case 3: {
	   				return new PyBoolean(saveJSONObject((processing.data.JSONObject)args[0].__tojava__(processing.data.JSONObject.class), args[1].asString(), args[2].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("delay",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"delay\" with " + args.length + " parameters."); 
	   			case 1: {
	   				delay(args[0].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("printCamera",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"printCamera\" with " + args.length + " parameters."); 
	   			case 0: {
	   				printCamera();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("emissive",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"emissive\" with " + args.length + " parameters."); 
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if (t0 == PyInteger.TYPE) {
	   					emissive(args[0].asInt());
	   				return Py.None;
	   				} else if ((t0 == PyFloat.TYPE || t0 == PyInteger.TYPE || t0 == PyLong.TYPE)) {
	   					emissive((float)args[0].asDouble());
	   				return Py.None;
	   				} else { throw new UnexpectedInvocationError("emissive", args, kws); }
	   			}
	   			case 3: {
	   				emissive((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("strokeJoin",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"strokeJoin\" with " + args.length + " parameters."); 
	   			case 1: {
	   				strokeJoin(args[0].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("endRecord",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"endRecord\" with " + args.length + " parameters."); 
	   			case 0: {
	   				endRecord();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("mouseMoved",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"mouseMoved\" with " + args.length + " parameters."); 
	   			case 0: {
	   				mouseMoved();
	   				return Py.None;
	   			}
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if (t0.getProxyType() != null && t0.getProxyType() == MouseEvent.class) {
	   					mouseMoved((java.awt.event.MouseEvent)args[0].__tojava__(java.awt.event.MouseEvent.class));
	   				return Py.None;
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == MouseEvent.class) {
	   					mouseMoved((processing.event.MouseEvent)args[0].__tojava__(processing.event.MouseEvent.class));
	   				return Py.None;
	   				} else { throw new UnexpectedInvocationError("mouseMoved", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("text",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"text\" with " + args.length + " parameters."); 
	   			case 3: {
	   				final PyType t0 = args[0].getType();
	   				final PyType t1 = args[1].getType();
	   				final PyType t2 = args[2].getType();
	   				if (t0 == PyInteger.TYPE && (t1 == PyFloat.TYPE || t1 == PyInteger.TYPE || t1 == PyLong.TYPE) && (t2 == PyFloat.TYPE || t2 == PyInteger.TYPE || t2 == PyLong.TYPE)) {
	   					text(args[0].asInt(), (float)args[1].asDouble(), (float)args[2].asDouble());
	   				return Py.None;
	   				} else if ((t0 == PyFloat.TYPE || t0 == PyInteger.TYPE || t0 == PyLong.TYPE) && (t1 == PyFloat.TYPE || t1 == PyInteger.TYPE || t1 == PyLong.TYPE) && (t2 == PyFloat.TYPE || t2 == PyInteger.TYPE || t2 == PyLong.TYPE)) {
	   					text((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble());
	   				return Py.None;
	   				} else if ((t0 == PyString.TYPE|| t0 == PyUnicode.TYPE) && (t1 == PyFloat.TYPE || t1 == PyInteger.TYPE || t1 == PyLong.TYPE) && (t2 == PyFloat.TYPE || t2 == PyInteger.TYPE || t2 == PyLong.TYPE)) {
	   					text(args[0].asString(), (float)args[1].asDouble(), (float)args[2].asDouble());
	   				return Py.None;
	   				} else { throw new UnexpectedInvocationError("text", args, kws); }
	   			}
	   			case 4: {
	   				final PyType t0 = args[0].getType();
	   				final PyType t1 = args[1].getType();
	   				final PyType t2 = args[2].getType();
	   				final PyType t3 = args[3].getType();
	   				if (t0 == PyInteger.TYPE && (t1 == PyFloat.TYPE || t1 == PyInteger.TYPE || t1 == PyLong.TYPE) && (t2 == PyFloat.TYPE || t2 == PyInteger.TYPE || t2 == PyLong.TYPE) && (t3 == PyFloat.TYPE || t3 == PyInteger.TYPE || t3 == PyLong.TYPE)) {
	   					text(args[0].asInt(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble());
	   				return Py.None;
	   				} else if ((t0 == PyFloat.TYPE || t0 == PyInteger.TYPE || t0 == PyLong.TYPE) && (t1 == PyFloat.TYPE || t1 == PyInteger.TYPE || t1 == PyLong.TYPE) && (t2 == PyFloat.TYPE || t2 == PyInteger.TYPE || t2 == PyLong.TYPE) && (t3 == PyFloat.TYPE || t3 == PyInteger.TYPE || t3 == PyLong.TYPE)) {
	   					text((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble());
	   				return Py.None;
	   				} else if ((t0 == PyString.TYPE|| t0 == PyUnicode.TYPE) && (t1 == PyFloat.TYPE || t1 == PyInteger.TYPE || t1 == PyLong.TYPE) && (t2 == PyFloat.TYPE || t2 == PyInteger.TYPE || t2 == PyLong.TYPE) && (t3 == PyFloat.TYPE || t3 == PyInteger.TYPE || t3 == PyLong.TYPE)) {
	   					text(args[0].asString(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble());
	   				return Py.None;
	   				} else { throw new UnexpectedInvocationError("text", args, kws); }
	   			}
	   			case 5: {
	   				text(args[0].asString(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("pointLight",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"pointLight\" with " + args.length + " parameters."); 
	   			case 6: {
	   				pointLight((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble(), (float)args[5].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("ortho",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"ortho\" with " + args.length + " parameters."); 
	   			case 0: {
	   				ortho();
	   				return Py.None;
	   			}
	   			case 4: {
	   				ortho((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble());
	   				return Py.None;
	   			}
	   			case 6: {
	   				ortho((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble(), (float)args[5].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("shearX",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"shearX\" with " + args.length + " parameters."); 
	   			case 1: {
	   				shearX((float)args[0].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("quadraticVertex",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"quadraticVertex\" with " + args.length + " parameters."); 
	   			case 4: {
	   				quadraticVertex((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble());
	   				return Py.None;
	   			}
	   			case 6: {
	   				quadraticVertex((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble(), (float)args[5].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("green",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"green\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyFloat(green(args[0].asInt()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("createImage",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"createImage\" with " + args.length + " parameters."); 
	   			case 3: {
	   				return Py.java2py(createImage(args[0].asInt(), args[1].asInt(), args[2].asInt()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("noCursor",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"noCursor\" with " + args.length + " parameters."); 
	   			case 0: {
	   				noCursor();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("saveStream",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"saveStream\" with " + args.length + " parameters."); 
	   			case 2: {
	   				final PyType t0 = args[0].getType();
	   				final PyType t1 = args[1].getType();
	   				if ((t0 == PyString.TYPE|| t0 == PyUnicode.TYPE) && (t1 == PyString.TYPE|| t1 == PyUnicode.TYPE)) {
	   					return new PyBoolean(saveStream(args[0].asString(), args[1].asString()));
	   				} else if ((t0 == PyString.TYPE|| t0 == PyUnicode.TYPE) && t1.getProxyType() != null && t1.getProxyType() == InputStream.class) {
	   					return new PyBoolean(saveStream(args[0].asString(), (java.io.InputStream)args[1].__tojava__(java.io.InputStream.class)));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == File.class && (t1 == PyString.TYPE|| t1 == PyUnicode.TYPE)) {
	   					return new PyBoolean(saveStream((java.io.File)args[0].__tojava__(java.io.File.class), args[1].asString()));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == File.class && t1.getProxyType() != null && t1.getProxyType() == InputStream.class) {
	   					return new PyBoolean(saveStream((java.io.File)args[0].__tojava__(java.io.File.class), (java.io.InputStream)args[1].__tojava__(java.io.InputStream.class)));
	   				} else { throw new UnexpectedInvocationError("saveStream", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("beginPGL",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"beginPGL\" with " + args.length + " parameters."); 
	   			case 0: {
	   				return Py.java2py(beginPGL());
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("mouseWheel",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"mouseWheel\" with " + args.length + " parameters."); 
	   			case 0: {
	   				mouseWheel();
	   				return Py.None;
	   			}
	   			case 1: {
	   				mouseWheel((processing.event.MouseEvent)args[0].__tojava__(processing.event.MouseEvent.class));
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("exp",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"exp\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyFloat(exp((float)args[0].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("noLights",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"noLights\" with " + args.length + " parameters."); 
	   			case 0: {
	   				noLights();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("curveTightness",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"curveTightness\" with " + args.length + " parameters."); 
	   			case 1: {
	   				curveTightness((float)args[0].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("join",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"join\" with " + args.length + " parameters."); 
	   			case 2: {
	   				return new PyUnicode(join((String[])args[0].__tojava__(String[].class), args[1].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("saveBytes",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"saveBytes\" with " + args.length + " parameters."); 
	   			case 2: {
	   				final PyType t0 = args[0].getType();
	   				final PyType t1 = args[1].getType();
	   				if ((t0 == PyString.TYPE|| t0 == PyUnicode.TYPE) && t1.getProxyType() != null && t1.getProxyType() == byte[].class) {
	   					saveBytes(args[0].asString(), (byte[])args[1].__tojava__(byte[].class));
	   				return Py.None;
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == OutputStream.class && t1.getProxyType() != null && t1.getProxyType() == byte[].class) {
	   					saveBytes((java.io.OutputStream)args[0].__tojava__(java.io.OutputStream.class), (byte[])args[1].__tojava__(byte[].class));
	   				return Py.None;
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == File.class && t1.getProxyType() != null && t1.getProxyType() == byte[].class) {
	   					saveBytes((java.io.File)args[0].__tojava__(java.io.File.class), (byte[])args[1].__tojava__(byte[].class));
	   				return Py.None;
	   				} else { throw new UnexpectedInvocationError("saveBytes", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("loop",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"loop\" with " + args.length + " parameters."); 
	   			case 0: {
	   				loop();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("copy",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"copy\" with " + args.length + " parameters."); 
	   			case 8: {
	   				copy(args[0].asInt(), args[1].asInt(), args[2].asInt(), args[3].asInt(), args[4].asInt(), args[5].asInt(), args[6].asInt(), args[7].asInt());
	   				return Py.None;
	   			}
	   			case 9: {
	   				copy((processing.core.PImage)args[0].__tojava__(processing.core.PImage.class), args[1].asInt(), args[2].asInt(), args[3].asInt(), args[4].asInt(), args[5].asInt(), args[6].asInt(), args[7].asInt(), args[8].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("createInputRaw",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"createInputRaw\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return Py.java2py(createInputRaw(args[0].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("textSize",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"textSize\" with " + args.length + " parameters."); 
	   			case 1: {
	   				textSize((float)args[0].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("second",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"second\" with " + args.length + " parameters."); 
	   			case 0: {
	   				return new PyInteger(second());
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("noise",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"noise\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyFloat(noise((float)args[0].asDouble()));
	   			}
	   			case 2: {
	   				return new PyFloat(noise((float)args[0].asDouble(), (float)args[1].asDouble()));
	   			}
	   			case 3: {
	   				return new PyFloat(noise((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("getExtension",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"getExtension\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyUnicode(getExtension(args[0].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("spotLight",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"spotLight\" with " + args.length + " parameters."); 
	   			case 11: {
	   				spotLight((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble(), (float)args[5].asDouble(), (float)args[6].asDouble(), (float)args[7].asDouble(), (float)args[8].asDouble(), (float)args[9].asDouble(), (float)args[10].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("sq",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"sq\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyFloat(sq((float)args[0].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("noiseDetail",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"noiseDetail\" with " + args.length + " parameters."); 
	   			case 1: {
	   				noiseDetail(args[0].asInt());
	   				return Py.None;
	   			}
	   			case 2: {
	   				noiseDetail(args[0].asInt(), (float)args[1].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("removeListeners",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"removeListeners\" with " + args.length + " parameters."); 
	   			case 1: {
	   				removeListeners((java.awt.Component)args[0].__tojava__(java.awt.Component.class));
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("loadBytes",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"loadBytes\" with " + args.length + " parameters."); 
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if ((t0 == PyString.TYPE|| t0 == PyUnicode.TYPE)) {
	   					return Py.java2py(loadBytes(args[0].asString()));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == InputStream.class) {
	   					return Py.java2py(loadBytes((java.io.InputStream)args[0].__tojava__(java.io.InputStream.class)));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == File.class) {
	   					return Py.java2py(loadBytes((java.io.File)args[0].__tojava__(java.io.File.class)));
	   				} else { throw new UnexpectedInvocationError("loadBytes", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("binary",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"binary\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyUnicode(binary(args[0].asInt()));
	   			}
	   			case 2: {
	   				return new PyUnicode(binary(args[0].asInt(), args[1].asInt()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("normal",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"normal\" with " + args.length + " parameters."); 
	   			case 3: {
	   				normal((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("getMatrix",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"getMatrix\" with " + args.length + " parameters."); 
	   			case 0: {
	   				return Py.java2py(getMatrix());
	   			}
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if (t0.getProxyType() != null && t0.getProxyType() == PMatrix3D.class) {
	   					return Py.java2py(getMatrix((processing.core.PMatrix3D)args[0].__tojava__(processing.core.PMatrix3D.class)));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == PMatrix2D.class) {
	   					return Py.java2py(getMatrix((processing.core.PMatrix2D)args[0].__tojava__(processing.core.PMatrix2D.class)));
	   				} else { throw new UnexpectedInvocationError("getMatrix", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("ellipse",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"ellipse\" with " + args.length + " parameters."); 
	   			case 4: {
	   				ellipse((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("subset",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"subset\" with " + args.length + " parameters."); 
	   			case 2: {
	   				final PyType t0 = args[0].getType();
	   				final PyType t1 = args[1].getType();
	   				if (t0.getProxyType() != null && t0.getProxyType() == int[].class && t1 == PyInteger.TYPE) {
	   					return Py.java2py(subset((int[])args[0].__tojava__(int[].class), args[1].asInt()));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == float[].class && t1 == PyInteger.TYPE) {
	   					return Py.java2py(subset((float[])args[0].__tojava__(float[].class), args[1].asInt()));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == byte[].class && t1 == PyInteger.TYPE) {
	   					return Py.java2py(subset((byte[])args[0].__tojava__(byte[].class), args[1].asInt()));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == boolean[].class && t1 == PyInteger.TYPE) {
	   					return Py.java2py(subset((boolean[])args[0].__tojava__(boolean[].class), args[1].asInt()));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == String[].class && t1 == PyInteger.TYPE) {
	   					return Py.java2py(subset((String[])args[0].__tojava__(String[].class), args[1].asInt()));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == Object.class && t1 == PyInteger.TYPE) {
	   					return Py.java2py(subset(args[0].__tojava__(java.lang.Object.class), args[1].asInt()));
	   				} else { throw new UnexpectedInvocationError("subset", args, kws); }
	   			}
	   			case 3: {
	   				final PyType t0 = args[0].getType();
	   				final PyType t1 = args[1].getType();
	   				final PyType t2 = args[2].getType();
	   				if (t0.getProxyType() != null && t0.getProxyType() == int[].class && t1 == PyInteger.TYPE && t2 == PyInteger.TYPE) {
	   					return Py.java2py(subset((int[])args[0].__tojava__(int[].class), args[1].asInt(), args[2].asInt()));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == float[].class && t1 == PyInteger.TYPE && t2 == PyInteger.TYPE) {
	   					return Py.java2py(subset((float[])args[0].__tojava__(float[].class), args[1].asInt(), args[2].asInt()));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == byte[].class && t1 == PyInteger.TYPE && t2 == PyInteger.TYPE) {
	   					return Py.java2py(subset((byte[])args[0].__tojava__(byte[].class), args[1].asInt(), args[2].asInt()));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == boolean[].class && t1 == PyInteger.TYPE && t2 == PyInteger.TYPE) {
	   					return Py.java2py(subset((boolean[])args[0].__tojava__(boolean[].class), args[1].asInt(), args[2].asInt()));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == String[].class && t1 == PyInteger.TYPE && t2 == PyInteger.TYPE) {
	   					return Py.java2py(subset((String[])args[0].__tojava__(String[].class), args[1].asInt(), args[2].asInt()));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == Object.class && t1 == PyInteger.TYPE && t2 == PyInteger.TYPE) {
	   					return Py.java2py(subset(args[0].__tojava__(java.lang.Object.class), args[1].asInt(), args[2].asInt()));
	   				} else { throw new UnexpectedInvocationError("subset", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("beginShape",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"beginShape\" with " + args.length + " parameters."); 
	   			case 0: {
	   				beginShape();
	   				return Py.None;
	   			}
	   			case 1: {
	   				beginShape(args[0].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("frustum",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"frustum\" with " + args.length + " parameters."); 
	   			case 6: {
	   				frustum((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble(), (float)args[5].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("rotateX",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"rotateX\" with " + args.length + " parameters."); 
	   			case 1: {
	   				rotateX((float)args[0].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("shearY",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"shearY\" with " + args.length + " parameters."); 
	   			case 1: {
	   				shearY((float)args[0].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("lightFalloff",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"lightFalloff\" with " + args.length + " parameters."); 
	   			case 3: {
	   				lightFalloff((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("year",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"year\" with " + args.length + " parameters."); 
	   			case 0: {
	   				return new PyInteger(year());
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("edge",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"edge\" with " + args.length + " parameters."); 
	   			case 1: {
	   				edge(args[0].__nonzero__());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("beginRaw",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"beginRaw\" with " + args.length + " parameters."); 
	   			case 1: {
	   				beginRaw((processing.core.PGraphics)args[0].__tojava__(processing.core.PGraphics.class));
	   				return Py.None;
	   			}
	   			case 2: {
	   				return Py.java2py(beginRaw(args[0].asString(), args[1].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("curveTangent",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"curveTangent\" with " + args.length + " parameters."); 
	   			case 5: {
	   				return new PyFloat(curveTangent((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("showMissingWarning",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"showMissingWarning\" with " + args.length + " parameters."); 
	   			case 1: {
	   				showMissingWarning(args[0].asString());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("resetShader",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"resetShader\" with " + args.length + " parameters."); 
	   			case 0: {
	   				resetShader();
	   				return Py.None;
	   			}
	   			case 1: {
	   				resetShader(args[0].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("background",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"background\" with " + args.length + " parameters."); 
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if (t0 == PyInteger.TYPE) {
	   					background(args[0].asInt());
	   				return Py.None;
	   				} else if ((t0 == PyFloat.TYPE || t0 == PyInteger.TYPE || t0 == PyLong.TYPE)) {
	   					background((float)args[0].asDouble());
	   				return Py.None;
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == PImage.class) {
	   					background((processing.core.PImage)args[0].__tojava__(processing.core.PImage.class));
	   				return Py.None;
	   				} else { throw new UnexpectedInvocationError("background", args, kws); }
	   			}
	   			case 2: {
	   				final PyType t0 = args[0].getType();
	   				final PyType t1 = args[1].getType();
	   				if (t0 == PyInteger.TYPE && (t1 == PyFloat.TYPE || t1 == PyInteger.TYPE || t1 == PyLong.TYPE)) {
	   					background(args[0].asInt(), (float)args[1].asDouble());
	   				return Py.None;
	   				} else if ((t0 == PyFloat.TYPE || t0 == PyInteger.TYPE || t0 == PyLong.TYPE) && (t1 == PyFloat.TYPE || t1 == PyInteger.TYPE || t1 == PyLong.TYPE)) {
	   					background((float)args[0].asDouble(), (float)args[1].asDouble());
	   				return Py.None;
	   				} else { throw new UnexpectedInvocationError("background", args, kws); }
	   			}
	   			case 3: {
	   				background((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble());
	   				return Py.None;
	   			}
	   			case 4: {
	   				background((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("day",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"day\" with " + args.length + " parameters."); 
	   			case 0: {
	   				return new PyInteger(day());
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("showMethodWarning",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"showMethodWarning\" with " + args.length + " parameters."); 
	   			case 1: {
	   				showMethodWarning(args[0].asString());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("arrayCopy",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"arrayCopy\" with " + args.length + " parameters."); 
	   			case 2: {
	   				arrayCopy(args[0].__tojava__(java.lang.Object.class), args[1].__tojava__(java.lang.Object.class));
	   				return Py.None;
	   			}
	   			case 3: {
	   				arrayCopy(args[0].__tojava__(java.lang.Object.class), args[1].__tojava__(java.lang.Object.class), args[2].asInt());
	   				return Py.None;
	   			}
	   			case 5: {
	   				arrayCopy(args[0].__tojava__(java.lang.Object.class), args[1].asInt(), args[2].__tojava__(java.lang.Object.class), args[3].asInt(), args[4].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("sin",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"sin\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyFloat(sin((float)args[0].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("splitTokens",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"splitTokens\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return Py.java2py(splitTokens(args[0].asString()));
	   			}
	   			case 2: {
	   				return Py.java2py(splitTokens(args[0].asString(), args[1].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("saveStrings",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"saveStrings\" with " + args.length + " parameters."); 
	   			case 2: {
	   				final PyType t0 = args[0].getType();
	   				final PyType t1 = args[1].getType();
	   				if ((t0 == PyString.TYPE|| t0 == PyUnicode.TYPE) && t1.getProxyType() != null && t1.getProxyType() == String[].class) {
	   					saveStrings(args[0].asString(), (String[])args[1].__tojava__(String[].class));
	   				return Py.None;
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == OutputStream.class && t1.getProxyType() != null && t1.getProxyType() == String[].class) {
	   					saveStrings((java.io.OutputStream)args[0].__tojava__(java.io.OutputStream.class), (String[])args[1].__tojava__(String[].class));
	   				return Py.None;
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == File.class && t1.getProxyType() != null && t1.getProxyType() == String[].class) {
	   					saveStrings((java.io.File)args[0].__tojava__(java.io.File.class), (String[])args[1].__tojava__(String[].class));
	   				return Py.None;
	   				} else { throw new UnexpectedInvocationError("saveStrings", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("constrain",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"constrain\" with " + args.length + " parameters."); 
	   			case 3: {
	   				final PyType t0 = args[0].getType();
	   				final PyType t1 = args[1].getType();
	   				final PyType t2 = args[2].getType();
	   				if (t0 == PyInteger.TYPE && t1 == PyInteger.TYPE && t2 == PyInteger.TYPE) {
	   					return new PyInteger(constrain(args[0].asInt(), args[1].asInt(), args[2].asInt()));
	   				} else if ((t0 == PyFloat.TYPE || t0 == PyInteger.TYPE || t0 == PyLong.TYPE) && (t1 == PyFloat.TYPE || t1 == PyInteger.TYPE || t1 == PyLong.TYPE) && (t2 == PyFloat.TYPE || t2 == PyInteger.TYPE || t2 == PyLong.TYPE)) {
	   					return new PyFloat(constrain((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble()));
	   				} else { throw new UnexpectedInvocationError("constrain", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("beginContour",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"beginContour\" with " + args.length + " parameters."); 
	   			case 0: {
	   				beginContour();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("loadPixels",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"loadPixels\" with " + args.length + " parameters."); 
	   			case 0: {
	   				loadPixels();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("shapeMode",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"shapeMode\" with " + args.length + " parameters."); 
	   			case 1: {
	   				shapeMode(args[0].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("popStyle",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"popStyle\" with " + args.length + " parameters."); 
	   			case 0: {
	   				popStyle();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("pow",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"pow\" with " + args.length + " parameters."); 
	   			case 2: {
	   				return new PyFloat(pow((float)args[0].asDouble(), (float)args[1].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("alpha",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"alpha\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyFloat(alpha(args[0].asInt()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("noLoop",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"noLoop\" with " + args.length + " parameters."); 
	   			case 0: {
	   				noLoop();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("textFont",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"textFont\" with " + args.length + " parameters."); 
	   			case 1: {
	   				textFont((processing.core.PFont)args[0].__tojava__(processing.core.PFont.class));
	   				return Py.None;
	   			}
	   			case 2: {
	   				textFont((processing.core.PFont)args[0].__tojava__(processing.core.PFont.class), (float)args[1].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("createWriter",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"createWriter\" with " + args.length + " parameters."); 
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if ((t0 == PyString.TYPE|| t0 == PyUnicode.TYPE)) {
	   					return Py.java2py(createWriter(args[0].asString()));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == OutputStream.class) {
	   					return Py.java2py(createWriter((java.io.OutputStream)args[0].__tojava__(java.io.OutputStream.class)));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == File.class) {
	   					return Py.java2py(createWriter((java.io.File)args[0].__tojava__(java.io.File.class)));
	   				} else { throw new UnexpectedInvocationError("createWriter", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("showDepthWarning",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"showDepthWarning\" with " + args.length + " parameters."); 
	   			case 1: {
	   				showDepthWarning(args[0].asString());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("pushMatrix",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"pushMatrix\" with " + args.length + " parameters."); 
	   			case 0: {
	   				pushMatrix();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("saveTable",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"saveTable\" with " + args.length + " parameters."); 
	   			case 2: {
	   				return new PyBoolean(saveTable((processing.data.Table)args[0].__tojava__(processing.data.Table.class), args[1].asString()));
	   			}
	   			case 3: {
	   				return new PyBoolean(saveTable((processing.data.Table)args[0].__tojava__(processing.data.Table.class), args[1].asString(), args[2].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("beginCamera",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"beginCamera\" with " + args.length + " parameters."); 
	   			case 0: {
	   				beginCamera();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("red",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"red\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyFloat(red(args[0].asInt()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("resetMatrix",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"resetMatrix\" with " + args.length + " parameters."); 
	   			case 0: {
	   				resetMatrix();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("dist",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"dist\" with " + args.length + " parameters."); 
	   			case 4: {
	   				return new PyFloat(dist((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble()));
	   			}
	   			case 6: {
	   				return new PyFloat(dist((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble(), (float)args[5].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("clear",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"clear\" with " + args.length + " parameters."); 
	   			case 0: {
	   				clear();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("blendColor",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"blendColor\" with " + args.length + " parameters."); 
	   			case 3: {
	   				return new PyInteger(blendColor(args[0].asInt(), args[1].asInt(), args[2].asInt()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("noStroke",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"noStroke\" with " + args.length + " parameters."); 
	   			case 0: {
	   				noStroke();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("createInput",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"createInput\" with " + args.length + " parameters."); 
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if ((t0 == PyString.TYPE|| t0 == PyUnicode.TYPE)) {
	   					return Py.java2py(createInput(args[0].asString()));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == File.class) {
	   					return Py.java2py(createInput((java.io.File)args[0].__tojava__(java.io.File.class)));
	   				} else { throw new UnexpectedInvocationError("createInput", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("split",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"split\" with " + args.length + " parameters."); 
	   			case 2: {
	   				return Py.java2py(split(args[0].asString(), args[1].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("nf",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"nf\" with " + args.length + " parameters."); 
	   			case 2: {
	   				final PyType t0 = args[0].getType();
	   				final PyType t1 = args[1].getType();
	   				if (t0.getProxyType() != null && t0.getProxyType() == int[].class && t1 == PyInteger.TYPE) {
	   					return Py.java2py(nf((int[])args[0].__tojava__(int[].class), args[1].asInt()));
	   				} else if (t0 == PyInteger.TYPE && t1 == PyInteger.TYPE) {
	   					return new PyUnicode(nf(args[0].asInt(), args[1].asInt()));
	   				} else { throw new UnexpectedInvocationError("nf", args, kws); }
	   			}
	   			case 3: {
	   				final PyType t0 = args[0].getType();
	   				final PyType t1 = args[1].getType();
	   				final PyType t2 = args[2].getType();
	   				if (t0.getProxyType() != null && t0.getProxyType() == float[].class && t1 == PyInteger.TYPE && t2 == PyInteger.TYPE) {
	   					return Py.java2py(nf((float[])args[0].__tojava__(float[].class), args[1].asInt(), args[2].asInt()));
	   				} else if ((t0 == PyFloat.TYPE || t0 == PyInteger.TYPE || t0 == PyLong.TYPE) && t1 == PyInteger.TYPE && t2 == PyInteger.TYPE) {
	   					return new PyUnicode(nf((float)args[0].asDouble(), args[1].asInt(), args[2].asInt()));
	   				} else { throw new UnexpectedInvocationError("nf", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("lightSpecular",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"lightSpecular\" with " + args.length + " parameters."); 
	   			case 3: {
	   				lightSpecular((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("texture",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"texture\" with " + args.length + " parameters."); 
	   			case 1: {
	   				texture((processing.core.PImage)args[0].__tojava__(processing.core.PImage.class));
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("endShape",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"endShape\" with " + args.length + " parameters."); 
	   			case 0: {
	   				endShape();
	   				return Py.None;
	   			}
	   			case 1: {
	   				endShape(args[0].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("reverse",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"reverse\" with " + args.length + " parameters."); 
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if (t0.getProxyType() != null && t0.getProxyType() == int[].class) {
	   					return Py.java2py(reverse((int[])args[0].__tojava__(int[].class)));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == float[].class) {
	   					return Py.java2py(reverse((float[])args[0].__tojava__(float[].class)));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == byte[].class) {
	   					return Py.java2py(reverse((byte[])args[0].__tojava__(byte[].class)));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == boolean[].class) {
	   					return Py.java2py(reverse((boolean[])args[0].__tojava__(boolean[].class)));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == String[].class) {
	   					return Py.java2py(reverse((String[])args[0].__tojava__(String[].class)));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == Object.class) {
	   					return Py.java2py(reverse(args[0].__tojava__(java.lang.Object.class)));
	   				} else { throw new UnexpectedInvocationError("reverse", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("printProjection",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"printProjection\" with " + args.length + " parameters."); 
	   			case 0: {
	   				printProjection();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("checkExtension",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"checkExtension\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyUnicode(checkExtension(args[0].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("popMatrix",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"popMatrix\" with " + args.length + " parameters."); 
	   			case 0: {
	   				popMatrix();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("modelX",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"modelX\" with " + args.length + " parameters."); 
	   			case 3: {
	   				return new PyFloat(modelX((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("textAlign",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"textAlign\" with " + args.length + " parameters."); 
	   			case 1: {
	   				textAlign(args[0].asInt());
	   				return Py.None;
	   			}
	   			case 2: {
	   				textAlign(args[0].asInt(), args[1].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("saturation",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"saturation\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyFloat(saturation(args[0].asInt()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("perspective",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"perspective\" with " + args.length + " parameters."); 
	   			case 0: {
	   				perspective();
	   				return Py.None;
	   			}
	   			case 4: {
	   				perspective((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("cursor",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"cursor\" with " + args.length + " parameters."); 
	   			case 0: {
	   				cursor();
	   				return Py.None;
	   			}
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if (t0 == PyInteger.TYPE) {
	   					cursor(args[0].asInt());
	   				return Py.None;
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == PImage.class) {
	   					cursor((processing.core.PImage)args[0].__tojava__(processing.core.PImage.class));
	   				return Py.None;
	   				} else { throw new UnexpectedInvocationError("cursor", args, kws); }
	   			}
	   			case 3: {
	   				cursor((processing.core.PImage)args[0].__tojava__(processing.core.PImage.class), args[1].asInt(), args[2].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("image",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"image\" with " + args.length + " parameters."); 
	   			case 3: {
	   				image((processing.core.PImage)args[0].__tojava__(processing.core.PImage.class), (float)args[1].asDouble(), (float)args[2].asDouble());
	   				return Py.None;
	   			}
	   			case 5: {
	   				image((processing.core.PImage)args[0].__tojava__(processing.core.PImage.class), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble());
	   				return Py.None;
	   			}
	   			case 9: {
	   				image((processing.core.PImage)args[0].__tojava__(processing.core.PImage.class), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble(), args[5].asInt(), args[6].asInt(), args[7].asInt(), args[8].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("curveDetail",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"curveDetail\" with " + args.length + " parameters."); 
	   			case 1: {
	   				curveDetail(args[0].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("mouseWheelMoved",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"mouseWheelMoved\" with " + args.length + " parameters."); 
	   			case 1: {
	   				mouseWheelMoved((java.awt.event.MouseWheelEvent)args[0].__tojava__(java.awt.event.MouseWheelEvent.class));
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("stroke",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"stroke\" with " + args.length + " parameters."); 
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if (t0 == PyInteger.TYPE) {
	   					stroke(args[0].asInt());
	   				return Py.None;
	   				} else if ((t0 == PyFloat.TYPE || t0 == PyInteger.TYPE || t0 == PyLong.TYPE)) {
	   					stroke((float)args[0].asDouble());
	   				return Py.None;
	   				} else { throw new UnexpectedInvocationError("stroke", args, kws); }
	   			}
	   			case 2: {
	   				final PyType t0 = args[0].getType();
	   				final PyType t1 = args[1].getType();
	   				if (t0 == PyInteger.TYPE && (t1 == PyFloat.TYPE || t1 == PyInteger.TYPE || t1 == PyLong.TYPE)) {
	   					stroke(args[0].asInt(), (float)args[1].asDouble());
	   				return Py.None;
	   				} else if ((t0 == PyFloat.TYPE || t0 == PyInteger.TYPE || t0 == PyLong.TYPE) && (t1 == PyFloat.TYPE || t1 == PyInteger.TYPE || t1 == PyLong.TYPE)) {
	   					stroke((float)args[0].asDouble(), (float)args[1].asDouble());
	   				return Py.None;
	   				} else { throw new UnexpectedInvocationError("stroke", args, kws); }
	   			}
	   			case 3: {
	   				stroke((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble());
	   				return Py.None;
	   			}
	   			case 4: {
	   				stroke((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("lerpColor",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"lerpColor\" with " + args.length + " parameters."); 
	   			case 3: {
	   				return new PyInteger(lerpColor(args[0].asInt(), args[1].asInt(), (float)args[2].asDouble()));
	   			}
	   			case 4: {
	   				return new PyInteger(lerpColor(args[0].asInt(), args[1].asInt(), (float)args[2].asDouble(), args[3].asInt()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("endContour",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"endContour\" with " + args.length + " parameters."); 
	   			case 0: {
	   				endContour();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("sphere",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"sphere\" with " + args.length + " parameters."); 
	   			case 1: {
	   				sphere((float)args[0].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("keyTyped",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"keyTyped\" with " + args.length + " parameters."); 
	   			case 0: {
	   				keyTyped();
	   				return Py.None;
	   			}
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if (t0.getProxyType() != null && t0.getProxyType() == KeyEvent.class) {
	   					keyTyped((java.awt.event.KeyEvent)args[0].__tojava__(java.awt.event.KeyEvent.class));
	   				return Py.None;
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == KeyEvent.class) {
	   					keyTyped((processing.event.KeyEvent)args[0].__tojava__(processing.event.KeyEvent.class));
	   				return Py.None;
	   				} else { throw new UnexpectedInvocationError("keyTyped", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("noTexture",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"noTexture\" with " + args.length + " parameters."); 
	   			case 0: {
	   				noTexture();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("loadJSONObject",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"loadJSONObject\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return Py.java2py(loadJSONObject(args[0].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("pushStyle",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"pushStyle\" with " + args.length + " parameters."); 
	   			case 0: {
	   				pushStyle();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("fill",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"fill\" with " + args.length + " parameters."); 
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if (t0 == PyInteger.TYPE) {
	   					fill(args[0].asInt());
	   				return Py.None;
	   				} else if ((t0 == PyFloat.TYPE || t0 == PyInteger.TYPE || t0 == PyLong.TYPE)) {
	   					fill((float)args[0].asDouble());
	   				return Py.None;
	   				} else { throw new UnexpectedInvocationError("fill", args, kws); }
	   			}
	   			case 2: {
	   				final PyType t0 = args[0].getType();
	   				final PyType t1 = args[1].getType();
	   				if (t0 == PyInteger.TYPE && (t1 == PyFloat.TYPE || t1 == PyInteger.TYPE || t1 == PyLong.TYPE)) {
	   					fill(args[0].asInt(), (float)args[1].asDouble());
	   				return Py.None;
	   				} else if ((t0 == PyFloat.TYPE || t0 == PyInteger.TYPE || t0 == PyLong.TYPE) && (t1 == PyFloat.TYPE || t1 == PyInteger.TYPE || t1 == PyLong.TYPE)) {
	   					fill((float)args[0].asDouble(), (float)args[1].asDouble());
	   				return Py.None;
	   				} else { throw new UnexpectedInvocationError("fill", args, kws); }
	   			}
	   			case 3: {
	   				fill((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble());
	   				return Py.None;
	   			}
	   			case 4: {
	   				fill((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("camera",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"camera\" with " + args.length + " parameters."); 
	   			case 0: {
	   				camera();
	   				return Py.None;
	   			}
	   			case 9: {
	   				camera((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble(), (float)args[5].asDouble(), (float)args[6].asDouble(), (float)args[7].asDouble(), (float)args[8].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("ambient",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"ambient\" with " + args.length + " parameters."); 
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if (t0 == PyInteger.TYPE) {
	   					ambient(args[0].asInt());
	   				return Py.None;
	   				} else if ((t0 == PyFloat.TYPE || t0 == PyInteger.TYPE || t0 == PyLong.TYPE)) {
	   					ambient((float)args[0].asDouble());
	   				return Py.None;
	   				} else { throw new UnexpectedInvocationError("ambient", args, kws); }
	   			}
	   			case 3: {
	   				ambient((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("modelZ",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"modelZ\" with " + args.length + " parameters."); 
	   			case 3: {
	   				return new PyFloat(modelZ((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("nfs",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"nfs\" with " + args.length + " parameters."); 
	   			case 2: {
	   				final PyType t0 = args[0].getType();
	   				final PyType t1 = args[1].getType();
	   				if (t0.getProxyType() != null && t0.getProxyType() == int[].class && t1 == PyInteger.TYPE) {
	   					return Py.java2py(nfs((int[])args[0].__tojava__(int[].class), args[1].asInt()));
	   				} else if (t0 == PyInteger.TYPE && t1 == PyInteger.TYPE) {
	   					return new PyUnicode(nfs(args[0].asInt(), args[1].asInt()));
	   				} else { throw new UnexpectedInvocationError("nfs", args, kws); }
	   			}
	   			case 3: {
	   				final PyType t0 = args[0].getType();
	   				final PyType t1 = args[1].getType();
	   				final PyType t2 = args[2].getType();
	   				if (t0.getProxyType() != null && t0.getProxyType() == float[].class && t1 == PyInteger.TYPE && t2 == PyInteger.TYPE) {
	   					return Py.java2py(nfs((float[])args[0].__tojava__(float[].class), args[1].asInt(), args[2].asInt()));
	   				} else if ((t0 == PyFloat.TYPE || t0 == PyInteger.TYPE || t0 == PyLong.TYPE) && t1 == PyInteger.TYPE && t2 == PyInteger.TYPE) {
	   					return new PyUnicode(nfs((float)args[0].asDouble(), args[1].asInt(), args[2].asInt()));
	   				} else { throw new UnexpectedInvocationError("nfs", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("saveXML",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"saveXML\" with " + args.length + " parameters."); 
	   			case 2: {
	   				return new PyBoolean(saveXML((processing.data.XML)args[0].__tojava__(processing.data.XML.class), args[1].asString()));
	   			}
	   			case 3: {
	   				return new PyBoolean(saveXML((processing.data.XML)args[0].__tojava__(processing.data.XML.class), args[1].asString(), args[2].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("curveVertex",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"curveVertex\" with " + args.length + " parameters."); 
	   			case 2: {
	   				curveVertex((float)args[0].asDouble(), (float)args[1].asDouble());
	   				return Py.None;
	   			}
	   			case 3: {
	   				curveVertex((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("saveJSONArray",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"saveJSONArray\" with " + args.length + " parameters."); 
	   			case 2: {
	   				return new PyBoolean(saveJSONArray((processing.data.JSONArray)args[0].__tojava__(processing.data.JSONArray.class), args[1].asString()));
	   			}
	   			case 3: {
	   				return new PyBoolean(saveJSONArray((processing.data.JSONArray)args[0].__tojava__(processing.data.JSONArray.class), args[1].asString(), args[2].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("randomGaussian",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"randomGaussian\" with " + args.length + " parameters."); 
	   			case 0: {
	   				return new PyFloat(randomGaussian());
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("hour",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"hour\" with " + args.length + " parameters."); 
	   			case 0: {
	   				return new PyInteger(hour());
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("atan",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"atan\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyFloat(atan((float)args[0].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("selectOutput",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"selectOutput\" with " + args.length + " parameters."); 
	   			case 2: {
	   				selectOutput(args[0].asString(), args[1].asString());
	   				return Py.None;
	   			}
	   			case 3: {
	   				selectOutput(args[0].asString(), args[1].asString(), (java.io.File)args[2].__tojava__(java.io.File.class));
	   				return Py.None;
	   			}
	   			case 4: {
	   				selectOutput(args[0].asString(), args[1].asString(), (java.io.File)args[2].__tojava__(java.io.File.class), args[3].__tojava__(java.lang.Object.class));
	   				return Py.None;
	   			}
	   			case 5: {
	   				selectOutput(args[0].asString(), args[1].asString(), (java.io.File)args[2].__tojava__(java.io.File.class), args[3].__tojava__(java.lang.Object.class), (java.awt.Frame)args[4].__tojava__(java.awt.Frame.class));
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("nfp",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"nfp\" with " + args.length + " parameters."); 
	   			case 2: {
	   				final PyType t0 = args[0].getType();
	   				final PyType t1 = args[1].getType();
	   				if (t0.getProxyType() != null && t0.getProxyType() == int[].class && t1 == PyInteger.TYPE) {
	   					return Py.java2py(nfp((int[])args[0].__tojava__(int[].class), args[1].asInt()));
	   				} else if (t0 == PyInteger.TYPE && t1 == PyInteger.TYPE) {
	   					return new PyUnicode(nfp(args[0].asInt(), args[1].asInt()));
	   				} else { throw new UnexpectedInvocationError("nfp", args, kws); }
	   			}
	   			case 3: {
	   				final PyType t0 = args[0].getType();
	   				final PyType t1 = args[1].getType();
	   				final PyType t2 = args[2].getType();
	   				if (t0.getProxyType() != null && t0.getProxyType() == float[].class && t1 == PyInteger.TYPE && t2 == PyInteger.TYPE) {
	   					return Py.java2py(nfp((float[])args[0].__tojava__(float[].class), args[1].asInt(), args[2].asInt()));
	   				} else if ((t0 == PyFloat.TYPE || t0 == PyInteger.TYPE || t0 == PyLong.TYPE) && t1 == PyInteger.TYPE && t2 == PyInteger.TYPE) {
	   					return new PyUnicode(nfp((float)args[0].asDouble(), args[1].asInt(), args[2].asInt()));
	   				} else { throw new UnexpectedInvocationError("nfp", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("directionalLight",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"directionalLight\" with " + args.length + " parameters."); 
	   			case 6: {
	   				directionalLight((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble(), (float)args[5].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("trim",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"trim\" with " + args.length + " parameters."); 
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if (t0.getProxyType() != null && t0.getProxyType() == String[].class) {
	   					return Py.java2py(trim((String[])args[0].__tojava__(String[].class)));
	   				} else if ((t0 == PyString.TYPE|| t0 == PyUnicode.TYPE)) {
	   					return new PyUnicode(trim(args[0].asString()));
	   				} else { throw new UnexpectedInvocationError("trim", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("bezierDetail",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"bezierDetail\" with " + args.length + " parameters."); 
	   			case 1: {
	   				bezierDetail(args[0].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("nfc",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"nfc\" with " + args.length + " parameters."); 
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if (t0.getProxyType() != null && t0.getProxyType() == int[].class) {
	   					return Py.java2py(nfc((int[])args[0].__tojava__(int[].class)));
	   				} else if (t0 == PyInteger.TYPE) {
	   					return new PyUnicode(nfc(args[0].asInt()));
	   				} else { throw new UnexpectedInvocationError("nfc", args, kws); }
	   			}
	   			case 2: {
	   				final PyType t0 = args[0].getType();
	   				final PyType t1 = args[1].getType();
	   				if (t0.getProxyType() != null && t0.getProxyType() == float[].class && t1 == PyInteger.TYPE) {
	   					return Py.java2py(nfc((float[])args[0].__tojava__(float[].class), args[1].asInt()));
	   				} else if ((t0 == PyFloat.TYPE || t0 == PyInteger.TYPE || t0 == PyLong.TYPE) && t1 == PyInteger.TYPE) {
	   					return new PyUnicode(nfc((float)args[0].asDouble(), args[1].asInt()));
	   				} else { throw new UnexpectedInvocationError("nfc", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("urlDecode",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"urlDecode\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyUnicode(urlDecode(args[0].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("createFont",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"createFont\" with " + args.length + " parameters."); 
	   			case 2: {
	   				return Py.java2py(createFont(args[0].asString(), (float)args[1].asDouble()));
	   			}
	   			case 3: {
	   				return Py.java2py(createFont(args[0].asString(), (float)args[1].asDouble(), args[2].__nonzero__()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("orientation",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"orientation\" with " + args.length + " parameters."); 
	   			case 1: {
	   				orientation(args[0].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("dispose",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"dispose\" with " + args.length + " parameters."); 
	   			case 0: {
	   				dispose();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("match",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"match\" with " + args.length + " parameters."); 
	   			case 2: {
	   				return Py.java2py(match(args[0].asString(), args[1].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("debug",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"debug\" with " + args.length + " parameters."); 
	   			case 1: {
	   				debug(args[0].asString());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("bezierTangent",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"bezierTangent\" with " + args.length + " parameters."); 
	   			case 5: {
	   				return new PyFloat(bezierTangent((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("printMatrix",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"printMatrix\" with " + args.length + " parameters."); 
	   			case 0: {
	   				printMatrix();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("urlEncode",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"urlEncode\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyUnicode(urlEncode(args[0].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("updatePixels",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"updatePixels\" with " + args.length + " parameters."); 
	   			case 0: {
	   				updatePixels();
	   				return Py.None;
	   			}
	   			case 4: {
	   				updatePixels(args[0].asInt(), args[1].asInt(), args[2].asInt(), args[3].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("textLeading",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"textLeading\" with " + args.length + " parameters."); 
	   			case 1: {
	   				textLeading((float)args[0].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("beginRecord",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"beginRecord\" with " + args.length + " parameters."); 
	   			case 1: {
	   				beginRecord((processing.core.PGraphics)args[0].__tojava__(processing.core.PGraphics.class));
	   				return Py.None;
	   			}
	   			case 2: {
	   				return Py.java2py(beginRecord(args[0].asString(), args[1].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("box",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"box\" with " + args.length + " parameters."); 
	   			case 1: {
	   				box((float)args[0].asDouble());
	   				return Py.None;
	   			}
	   			case 3: {
	   				box((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("cos",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"cos\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyFloat(cos((float)args[0].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("ceil",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"ceil\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyInteger(ceil((float)args[0].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("atan2",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"atan2\" with " + args.length + " parameters."); 
	   			case 2: {
	   				return new PyFloat(atan2((float)args[0].asDouble(), (float)args[1].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("isGL",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"isGL\" with " + args.length + " parameters."); 
	   			case 0: {
	   				return new PyBoolean(isGL());
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("noClip",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"noClip\" with " + args.length + " parameters."); 
	   			case 0: {
	   				noClip();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("size",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"size\" with " + args.length + " parameters."); 
	   			case 2: {
	   				size(args[0].asInt(), args[1].asInt());
	   				return Py.None;
	   			}
	   			case 3: {
	   				size(args[0].asInt(), args[1].asInt(), args[2].asString());
	   				return Py.None;
	   			}
	   			case 4: {
	   				size(args[0].asInt(), args[1].asInt(), args[2].asString(), args[3].asString());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("loadStrings",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"loadStrings\" with " + args.length + " parameters."); 
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if ((t0 == PyString.TYPE|| t0 == PyUnicode.TYPE)) {
	   					return Py.java2py(loadStrings(args[0].asString()));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == InputStream.class) {
	   					return Py.java2py(loadStrings((java.io.InputStream)args[0].__tojava__(java.io.InputStream.class)));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == File.class) {
	   					return Py.java2py(loadStrings((java.io.File)args[0].__tojava__(java.io.File.class)));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == BufferedReader.class) {
	   					return Py.java2py(loadStrings((java.io.BufferedReader)args[0].__tojava__(java.io.BufferedReader.class)));
	   				} else { throw new UnexpectedInvocationError("loadStrings", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("random",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"random\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyFloat(random((float)args[0].asDouble()));
	   			}
	   			case 2: {
	   				return new PyFloat(random((float)args[0].asDouble(), (float)args[1].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("insertFrame",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"insertFrame\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyUnicode(insertFrame(args[0].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("redraw",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"redraw\" with " + args.length + " parameters."); 
	   			case 0: {
	   				redraw();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("blend",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"blend\" with " + args.length + " parameters."); 
	   			case 9: {
	   				blend(args[0].asInt(), args[1].asInt(), args[2].asInt(), args[3].asInt(), args[4].asInt(), args[5].asInt(), args[6].asInt(), args[7].asInt(), args[8].asInt());
	   				return Py.None;
	   			}
	   			case 10: {
	   				blend((processing.core.PImage)args[0].__tojava__(processing.core.PImage.class), args[1].asInt(), args[2].asInt(), args[3].asInt(), args[4].asInt(), args[5].asInt(), args[6].asInt(), args[7].asInt(), args[8].asInt(), args[9].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("saveFrame",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"saveFrame\" with " + args.length + " parameters."); 
	   			case 0: {
	   				saveFrame();
	   				return Py.None;
	   			}
	   			case 1: {
	   				saveFrame(args[0].asString());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("bezier",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"bezier\" with " + args.length + " parameters."); 
	   			case 8: {
	   				bezier((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble(), (float)args[5].asDouble(), (float)args[6].asDouble(), (float)args[7].asDouble());
	   				return Py.None;
	   			}
	   			case 12: {
	   				bezier((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble(), (float)args[5].asDouble(), (float)args[6].asDouble(), (float)args[7].asDouble(), (float)args[8].asDouble(), (float)args[9].asDouble(), (float)args[10].asDouble(), (float)args[11].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   final PyObject map_builtin = builtins.__getitem__("map");
	   builtins.__setitem__("map",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				return map_builtin.__call__(args, kws);
	   			case 5: {
	   				final PyType t0 = args[0].getType();
	   				final PyType t1 = args[1].getType();
	   				final PyType t2 = args[2].getType();
	   				final PyType t3 = args[3].getType();
	   				final PyType t4 = args[4].getType();
	   				if ((t0 == PyFloat.TYPE || t0 == PyInteger.TYPE || t0 == PyLong.TYPE) && (t1 == PyFloat.TYPE || t1 == PyInteger.TYPE || t1 == PyLong.TYPE) && (t2 == PyFloat.TYPE || t2 == PyInteger.TYPE || t2 == PyLong.TYPE) && (t3 == PyFloat.TYPE || t3 == PyInteger.TYPE || t3 == PyLong.TYPE) && (t4 == PyFloat.TYPE || t4 == PyInteger.TYPE || t4 == PyLong.TYPE)) {
	   					return new PyFloat(map((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble()));
	   				} else { return map_builtin.__call__(args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("month",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"month\" with " + args.length + " parameters."); 
	   			case 0: {
	   				return new PyInteger(month());
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("updateListeners",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"updateListeners\" with " + args.length + " parameters."); 
	   			case 1: {
	   				updateListeners((java.awt.Component)args[0].__tojava__(java.awt.Component.class));
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("shader",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"shader\" with " + args.length + " parameters."); 
	   			case 1: {
	   				shader((processing.opengl.PShader)args[0].__tojava__(processing.opengl.PShader.class));
	   				return Py.None;
	   			}
	   			case 2: {
	   				shader((processing.opengl.PShader)args[0].__tojava__(processing.opengl.PShader.class), args[1].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("rotate",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"rotate\" with " + args.length + " parameters."); 
	   			case 1: {
	   				rotate((float)args[0].asDouble());
	   				return Py.None;
	   			}
	   			case 4: {
	   				rotate((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("createShape",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"createShape\" with " + args.length + " parameters."); 
	   			case 0: {
	   				return Py.java2py(createShape());
	   			}
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if (t0 == PyInteger.TYPE) {
	   					return Py.java2py(createShape(args[0].asInt()));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == PShape.class) {
	   					return Py.java2py(createShape((processing.core.PShape)args[0].__tojava__(processing.core.PShape.class)));
	   				} else { throw new UnexpectedInvocationError("createShape", args, kws); }
	   			}
	   			case 2: {
	   				return Py.java2py(createShape(args[0].asInt(), (float[])args[1].__tojava__(float[].class)));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("run",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"run\" with " + args.length + " parameters."); 
	   			case 0: {
	   				run();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("sphereDetail",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"sphereDetail\" with " + args.length + " parameters."); 
	   			case 1: {
	   				sphereDetail(args[0].asInt());
	   				return Py.None;
	   			}
	   			case 2: {
	   				sphereDetail(args[0].asInt(), args[1].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("degrees",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"degrees\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyFloat(degrees((float)args[0].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("println",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"println\" with " + args.length + " parameters."); 
	   			case 0: {
	   				println();
	   				return Py.None;
	   			}
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if (t0 == PyLong.TYPE) {
	   					println(args[0].asLong());
	   				return Py.None;
	   				} else if (t0 == PyInteger.TYPE) {
	   					println(args[0].asInt());
	   				return Py.None;
	   				} else if ((t0 == PyFloat.TYPE || t0 == PyInteger.TYPE || t0 == PyLong.TYPE)) {
	   					println((float)args[0].asDouble());
	   				return Py.None;
	   				} else if (t0 == PyFloat.TYPE) {
	   					println(args[0].asDouble());
	   				return Py.None;
	   				} else if (t0 == PyBoolean.TYPE) {
	   					println(args[0].__nonzero__());
	   				return Py.None;
	   				} else if ((t0 == PyString.TYPE|| t0 == PyUnicode.TYPE)) {
	   					println(args[0].asString());
	   				return Py.None;
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == Object.class) {
	   					println(args[0].__tojava__(java.lang.Object.class));
	   				return Py.None;
	   				} else { throw new UnexpectedInvocationError("println", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("asin",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"asin\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyFloat(asin((float)args[0].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("showDepthWarningXYZ",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"showDepthWarningXYZ\" with " + args.length + " parameters."); 
	   			case 1: {
	   				showDepthWarningXYZ(args[0].asString());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("textWidth",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"textWidth\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyFloat(textWidth(args[0].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("shorten",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"shorten\" with " + args.length + " parameters."); 
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if (t0.getProxyType() != null && t0.getProxyType() == int[].class) {
	   					return Py.java2py(shorten((int[])args[0].__tojava__(int[].class)));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == float[].class) {
	   					return Py.java2py(shorten((float[])args[0].__tojava__(float[].class)));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == byte[].class) {
	   					return Py.java2py(shorten((byte[])args[0].__tojava__(byte[].class)));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == boolean[].class) {
	   					return Py.java2py(shorten((boolean[])args[0].__tojava__(boolean[].class)));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == String[].class) {
	   					return Py.java2py(shorten((String[])args[0].__tojava__(String[].class)));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == Object.class) {
	   					return Py.java2py(shorten(args[0].__tojava__(java.lang.Object.class)));
	   				} else { throw new UnexpectedInvocationError("shorten", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("loadFont",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"loadFont\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return Py.java2py(loadFont(args[0].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("triangle",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"triangle\" with " + args.length + " parameters."); 
	   			case 6: {
	   				triangle((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble(), (float)args[5].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("endPGL",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"endPGL\" with " + args.length + " parameters."); 
	   			case 0: {
	   				endPGL();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("createOutput",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"createOutput\" with " + args.length + " parameters."); 
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if ((t0 == PyString.TYPE|| t0 == PyUnicode.TYPE)) {
	   					return Py.java2py(createOutput(args[0].asString()));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == File.class) {
	   					return Py.java2py(createOutput((java.io.File)args[0].__tojava__(java.io.File.class)));
	   				} else { throw new UnexpectedInvocationError("createOutput", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("textMode",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"textMode\" with " + args.length + " parameters."); 
	   			case 1: {
	   				textMode(args[0].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("mouseClicked",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"mouseClicked\" with " + args.length + " parameters."); 
	   			case 0: {
	   				mouseClicked();
	   				return Py.None;
	   			}
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if (t0.getProxyType() != null && t0.getProxyType() == MouseEvent.class) {
	   					mouseClicked((java.awt.event.MouseEvent)args[0].__tojava__(java.awt.event.MouseEvent.class));
	   				return Py.None;
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == MouseEvent.class) {
	   					mouseClicked((processing.event.MouseEvent)args[0].__tojava__(processing.event.MouseEvent.class));
	   				return Py.None;
	   				} else { throw new UnexpectedInvocationError("mouseClicked", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("showVariationWarning",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"showVariationWarning\" with " + args.length + " parameters."); 
	   			case 1: {
	   				showVariationWarning(args[0].asString());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("hue",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"hue\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyFloat(hue(args[0].asInt()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("screenY",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"screenY\" with " + args.length + " parameters."); 
	   			case 2: {
	   				return new PyFloat(screenY((float)args[0].asDouble(), (float)args[1].asDouble()));
	   			}
	   			case 3: {
	   				return new PyFloat(screenY((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("mask",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"mask\" with " + args.length + " parameters."); 
	   			case 1: {
	   				mask((processing.core.PImage)args[0].__tojava__(processing.core.PImage.class));
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   final PyObject filter_builtin = builtins.__getitem__("filter");
	   builtins.__setitem__("filter",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				return filter_builtin.__call__(args, kws);
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if (t0 == PyInteger.TYPE) {
	   					filter(args[0].asInt());
	   				return Py.None;
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == PShader.class) {
	   					filter((processing.opengl.PShader)args[0].__tojava__(processing.opengl.PShader.class));
	   				return Py.None;
	   				} else { return filter_builtin.__call__(args, kws); }
	   			}
	   			case 2: {
	   				final PyType t0 = args[0].getType();
	   				final PyType t1 = args[1].getType();
	   				if (t0 == PyInteger.TYPE && (t1 == PyFloat.TYPE || t1 == PyInteger.TYPE || t1 == PyLong.TYPE)) {
	   					filter(args[0].asInt(), (float)args[1].asDouble());
	   				return Py.None;
	   				} else { return filter_builtin.__call__(args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("blue",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"blue\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyFloat(blue(args[0].asInt()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("hex",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"hex\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyUnicode(hex(args[0].asInt()));
	   			}
	   			case 2: {
	   				return new PyUnicode(hex(args[0].asInt(), args[1].asInt()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("brightness",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"brightness\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyFloat(brightness(args[0].asInt()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("norm",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"norm\" with " + args.length + " parameters."); 
	   			case 3: {
	   				return new PyFloat(norm((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("log",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"log\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return new PyFloat(log((float)args[0].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("strokeCap",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"strokeCap\" with " + args.length + " parameters."); 
	   			case 1: {
	   				strokeCap(args[0].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("imageMode",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"imageMode\" with " + args.length + " parameters."); 
	   			case 1: {
	   				imageMode(args[0].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("mag",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"mag\" with " + args.length + " parameters."); 
	   			case 2: {
	   				return new PyFloat(mag((float)args[0].asDouble(), (float)args[1].asDouble()));
	   			}
	   			case 3: {
	   				return new PyFloat(mag((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("endRaw",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"endRaw\" with " + args.length + " parameters."); 
	   			case 0: {
	   				endRaw();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("selectFolder",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"selectFolder\" with " + args.length + " parameters."); 
	   			case 2: {
	   				selectFolder(args[0].asString(), args[1].asString());
	   				return Py.None;
	   			}
	   			case 3: {
	   				selectFolder(args[0].asString(), args[1].asString(), (java.io.File)args[2].__tojava__(java.io.File.class));
	   				return Py.None;
	   			}
	   			case 4: {
	   				selectFolder(args[0].asString(), args[1].asString(), (java.io.File)args[2].__tojava__(java.io.File.class), args[3].__tojava__(java.lang.Object.class));
	   				return Py.None;
	   			}
	   			case 5: {
	   				selectFolder(args[0].asString(), args[1].asString(), (java.io.File)args[2].__tojava__(java.io.File.class), args[3].__tojava__(java.lang.Object.class), (java.awt.Frame)args[4].__tojava__(java.awt.Frame.class));
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("textureMode",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"textureMode\" with " + args.length + " parameters."); 
	   			case 1: {
	   				textureMode(args[0].asInt());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("mouseDragged",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"mouseDragged\" with " + args.length + " parameters."); 
	   			case 0: {
	   				mouseDragged();
	   				return Py.None;
	   			}
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if (t0.getProxyType() != null && t0.getProxyType() == MouseEvent.class) {
	   					mouseDragged((java.awt.event.MouseEvent)args[0].__tojava__(java.awt.event.MouseEvent.class));
	   				return Py.None;
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == MouseEvent.class) {
	   					mouseDragged((processing.event.MouseEvent)args[0].__tojava__(processing.event.MouseEvent.class));
	   				return Py.None;
	   				} else { throw new UnexpectedInvocationError("mouseDragged", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("noTint",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"noTint\" with " + args.length + " parameters."); 
	   			case 0: {
	   				noTint();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("randomSeed",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"randomSeed\" with " + args.length + " parameters."); 
	   			case 1: {
	   				randomSeed(args[0].asLong());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("postEvent",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"postEvent\" with " + args.length + " parameters."); 
	   			case 1: {
	   				postEvent((processing.event.Event)args[0].__tojava__(processing.event.Event.class));
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("rotateY",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"rotateY\" with " + args.length + " parameters."); 
	   			case 1: {
	   				rotateY((float)args[0].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("scale",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"scale\" with " + args.length + " parameters."); 
	   			case 1: {
	   				scale((float)args[0].asDouble());
	   				return Py.None;
	   			}
	   			case 2: {
	   				scale((float)args[0].asDouble(), (float)args[1].asDouble());
	   				return Py.None;
	   			}
	   			case 3: {
	   				scale((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("setMatrix",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"setMatrix\" with " + args.length + " parameters."); 
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if (t0.getProxyType() != null && t0.getProxyType() == PMatrix3D.class) {
	   					setMatrix((processing.core.PMatrix3D)args[0].__tojava__(processing.core.PMatrix3D.class));
	   				return Py.None;
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == PMatrix2D.class) {
	   					setMatrix((processing.core.PMatrix2D)args[0].__tojava__(processing.core.PMatrix2D.class));
	   				return Py.None;
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == PMatrix.class) {
	   					setMatrix((processing.core.PMatrix)args[0].__tojava__(processing.core.PMatrix.class));
	   				return Py.None;
	   				} else { throw new UnexpectedInvocationError("setMatrix", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("loadShape",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"loadShape\" with " + args.length + " parameters."); 
	   			case 1: {
	   				return Py.java2py(loadShape(args[0].asString()));
	   			}
	   			case 2: {
	   				return Py.java2py(loadShape(args[0].asString(), args[1].asString()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("color",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"color\" with " + args.length + " parameters."); 
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if (t0 == PyInteger.TYPE) {
	   					return new PyInteger(color(args[0].asInt()));
	   				} else if ((t0 == PyFloat.TYPE || t0 == PyInteger.TYPE || t0 == PyLong.TYPE)) {
	   					return new PyInteger(color((float)args[0].asDouble()));
	   				} else { throw new UnexpectedInvocationError("color", args, kws); }
	   			}
	   			case 2: {
	   				final PyType t0 = args[0].getType();
	   				final PyType t1 = args[1].getType();
	   				if (t0 == PyInteger.TYPE && t1 == PyInteger.TYPE) {
	   					return new PyInteger(color(args[0].asInt(), args[1].asInt()));
	   				} else if ((t0 == PyFloat.TYPE || t0 == PyInteger.TYPE || t0 == PyLong.TYPE) && (t1 == PyFloat.TYPE || t1 == PyInteger.TYPE || t1 == PyLong.TYPE)) {
	   					return new PyInteger(color((float)args[0].asDouble(), (float)args[1].asDouble()));
	   				} else { throw new UnexpectedInvocationError("color", args, kws); }
	   			}
	   			case 3: {
	   				final PyType t0 = args[0].getType();
	   				final PyType t1 = args[1].getType();
	   				final PyType t2 = args[2].getType();
	   				if (t0 == PyInteger.TYPE && t1 == PyInteger.TYPE && t2 == PyInteger.TYPE) {
	   					return new PyInteger(color(args[0].asInt(), args[1].asInt(), args[2].asInt()));
	   				} else if ((t0 == PyFloat.TYPE || t0 == PyInteger.TYPE || t0 == PyLong.TYPE) && (t1 == PyFloat.TYPE || t1 == PyInteger.TYPE || t1 == PyLong.TYPE) && (t2 == PyFloat.TYPE || t2 == PyInteger.TYPE || t2 == PyLong.TYPE)) {
	   					return new PyInteger(color((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble()));
	   				} else { throw new UnexpectedInvocationError("color", args, kws); }
	   			}
	   			case 4: {
	   				final PyType t0 = args[0].getType();
	   				final PyType t1 = args[1].getType();
	   				final PyType t2 = args[2].getType();
	   				final PyType t3 = args[3].getType();
	   				if (t0 == PyInteger.TYPE && t1 == PyInteger.TYPE && t2 == PyInteger.TYPE && t3 == PyInteger.TYPE) {
	   					return new PyInteger(color(args[0].asInt(), args[1].asInt(), args[2].asInt(), args[3].asInt()));
	   				} else if ((t0 == PyFloat.TYPE || t0 == PyInteger.TYPE || t0 == PyLong.TYPE) && (t1 == PyFloat.TYPE || t1 == PyInteger.TYPE || t1 == PyLong.TYPE) && (t2 == PyFloat.TYPE || t2 == PyInteger.TYPE || t2 == PyLong.TYPE) && (t3 == PyFloat.TYPE || t3 == PyInteger.TYPE || t3 == PyLong.TYPE)) {
	   					return new PyInteger(color((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble()));
	   				} else { throw new UnexpectedInvocationError("color", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("endCamera",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"endCamera\" with " + args.length + " parameters."); 
	   			case 0: {
	   				endCamera();
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("tint",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"tint\" with " + args.length + " parameters."); 
	   			case 1: {
	   				final PyType t0 = args[0].getType();
	   				if (t0 == PyInteger.TYPE) {
	   					tint(args[0].asInt());
	   				return Py.None;
	   				} else if ((t0 == PyFloat.TYPE || t0 == PyInteger.TYPE || t0 == PyLong.TYPE)) {
	   					tint((float)args[0].asDouble());
	   				return Py.None;
	   				} else { throw new UnexpectedInvocationError("tint", args, kws); }
	   			}
	   			case 2: {
	   				final PyType t0 = args[0].getType();
	   				final PyType t1 = args[1].getType();
	   				if (t0 == PyInteger.TYPE && (t1 == PyFloat.TYPE || t1 == PyInteger.TYPE || t1 == PyLong.TYPE)) {
	   					tint(args[0].asInt(), (float)args[1].asDouble());
	   				return Py.None;
	   				} else if ((t0 == PyFloat.TYPE || t0 == PyInteger.TYPE || t0 == PyLong.TYPE) && (t1 == PyFloat.TYPE || t1 == PyInteger.TYPE || t1 == PyLong.TYPE)) {
	   					tint((float)args[0].asDouble(), (float)args[1].asDouble());
	   				return Py.None;
	   				} else { throw new UnexpectedInvocationError("tint", args, kws); }
	   			}
	   			case 3: {
	   				tint((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble());
	   				return Py.None;
	   			}
	   			case 4: {
	   				tint((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("modelY",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"modelY\" with " + args.length + " parameters."); 
	   			case 3: {
	   				return new PyFloat(modelY((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble()));
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("shininess",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"shininess\" with " + args.length + " parameters."); 
	   			case 1: {
	   				shininess((float)args[0].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("bezierVertex",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"bezierVertex\" with " + args.length + " parameters."); 
	   			case 6: {
	   				bezierVertex((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble(), (float)args[5].asDouble());
	   				return Py.None;
	   			}
	   			case 9: {
	   				bezierVertex((float)args[0].asDouble(), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble(), (float)args[5].asDouble(), (float)args[6].asDouble(), (float)args[7].asDouble(), (float)args[8].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("selectInput",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"selectInput\" with " + args.length + " parameters."); 
	   			case 2: {
	   				selectInput(args[0].asString(), args[1].asString());
	   				return Py.None;
	   			}
	   			case 3: {
	   				selectInput(args[0].asString(), args[1].asString(), (java.io.File)args[2].__tojava__(java.io.File.class));
	   				return Py.None;
	   			}
	   			case 4: {
	   				selectInput(args[0].asString(), args[1].asString(), (java.io.File)args[2].__tojava__(java.io.File.class), args[3].__tojava__(java.lang.Object.class));
	   				return Py.None;
	   			}
	   			case 5: {
	   				selectInput(args[0].asString(), args[1].asString(), (java.io.File)args[2].__tojava__(java.io.File.class), args[3].__tojava__(java.lang.Object.class), (java.awt.Frame)args[4].__tojava__(java.awt.Frame.class));
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("concat",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"concat\" with " + args.length + " parameters."); 
	   			case 2: {
	   				final PyType t0 = args[0].getType();
	   				final PyType t1 = args[1].getType();
	   				if (t0.getProxyType() != null && t0.getProxyType() == int[].class && t1.getProxyType() != null && t1.getProxyType() == int[].class) {
	   					return Py.java2py(concat((int[])args[0].__tojava__(int[].class), (int[])args[1].__tojava__(int[].class)));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == float[].class && t1.getProxyType() != null && t1.getProxyType() == float[].class) {
	   					return Py.java2py(concat((float[])args[0].__tojava__(float[].class), (float[])args[1].__tojava__(float[].class)));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == byte[].class && t1.getProxyType() != null && t1.getProxyType() == byte[].class) {
	   					return Py.java2py(concat((byte[])args[0].__tojava__(byte[].class), (byte[])args[1].__tojava__(byte[].class)));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == boolean[].class && t1.getProxyType() != null && t1.getProxyType() == boolean[].class) {
	   					return Py.java2py(concat((boolean[])args[0].__tojava__(boolean[].class), (boolean[])args[1].__tojava__(boolean[].class)));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == String[].class && t1.getProxyType() != null && t1.getProxyType() == String[].class) {
	   					return Py.java2py(concat((String[])args[0].__tojava__(String[].class), (String[])args[1].__tojava__(String[].class)));
	   				} else if (t0.getProxyType() != null && t0.getProxyType() == Object.class && t1.getProxyType() != null && t1.getProxyType() == Object.class) {
	   					return Py.java2py(concat(args[0].__tojava__(java.lang.Object.class), args[1].__tojava__(java.lang.Object.class)));
	   				} else { throw new UnexpectedInvocationError("concat", args, kws); }
	   			}
	   		}
	   	}
	   });
	   builtins.__setitem__("shape",new PyObject(){
	   	public PyObject __call__(final PyObject[] args, final String[] kws) {
	   		switch(args.length) {
	   			default: 
	   				throw new RuntimeException("Can't call \"shape\" with " + args.length + " parameters."); 
	   			case 1: {
	   				shape((processing.core.PShape)args[0].__tojava__(processing.core.PShape.class));
	   				return Py.None;
	   			}
	   			case 3: {
	   				shape((processing.core.PShape)args[0].__tojava__(processing.core.PShape.class), (float)args[1].asDouble(), (float)args[2].asDouble());
	   				return Py.None;
	   			}
	   			case 5: {
	   				shape((processing.core.PShape)args[0].__tojava__(processing.core.PShape.class), (float)args[1].asDouble(), (float)args[2].asDouble(), (float)args[3].asDouble(), (float)args[4].asDouble());
	   				return Py.None;
	   			}
	   		}
	   	}
	   });
	   /*[[[end]]]*/
	}

	@Override
	protected void setFields() {
       /*[[[cog
       for b in p.field_bindings:
           b.emit()
       ]]]*/
       builtins.__setitem__("width",new PyInteger(width));
       builtins.__setitem__("height",new PyInteger(height));
       builtins.__setitem__("pmouseY",new PyInteger(pmouseY));
       builtins.__setitem__("paused",new PyBoolean(paused));
       builtins.__setitem__("mouseX",new PyInteger(mouseX));
       builtins.__setitem__("focused",new PyBoolean(focused));
       builtins.__setitem__("key",new PyInteger(key));
       builtins.__setitem__("pixels",Py.java2py(pixels));
       builtins.__setitem__("displayHeight",new PyInteger(displayHeight));
       builtins.__setitem__("keyPressed",new PyBoolean(keyPressed));
       builtins.__setitem__("frameCount",new PyInteger(frameCount));
       builtins.__setitem__("mouseButton",new PyInteger(mouseButton));
       builtins.__setitem__("pmouseX",new PyInteger(pmouseX));
       builtins.__setitem__("keyCode",new PyInteger(keyCode));
       builtins.__setitem__("mousePressed",new PyBoolean(mousePressed));
       builtins.__setitem__("frameRate",new PyFloat(frameRate){
       	public PyObject __call__(final PyObject[] args, final String[] kws) {
       		switch(args.length) {
       			default: 
       				throw new RuntimeException("Can't call \"frameRate\" with " + args.length + " parameters."); 
       			case 1: {
       				frameRate((float)args[0].asDouble());
       				return Py.None;
       			}
       		}
       	}
       });
       builtins.__setitem__("displayWidth",new PyInteger(displayWidth));
       builtins.__setitem__("mouseY",new PyInteger(mouseY));
       /*[[[end]]] */
       super.setFields();
	}
}
