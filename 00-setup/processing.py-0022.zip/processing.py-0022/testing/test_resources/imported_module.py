def sayok():
    print("OK!")