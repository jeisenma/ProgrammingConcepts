import imported_module

imported_module.sayok()
exit()