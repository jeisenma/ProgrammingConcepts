size(100, 100)
loadPixels()
pixels[10] = color(10,0,255)
updatePixels()
print 'OK'
exit()
