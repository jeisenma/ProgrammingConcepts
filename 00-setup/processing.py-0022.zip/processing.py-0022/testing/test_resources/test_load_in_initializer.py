# To change this template, choose Tools | Templates
# and open the template in the editor.

__author__="max.franks"

font = loadFont(pwd("data/Cabal1-48.vlw"))

def setup():
    size(10, 10, P3D)
    noLoop();
    print 'OK'
    exit()
