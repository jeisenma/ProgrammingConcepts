start = millis()
delay(2)
print millis() > 2
# expect True
exit()
